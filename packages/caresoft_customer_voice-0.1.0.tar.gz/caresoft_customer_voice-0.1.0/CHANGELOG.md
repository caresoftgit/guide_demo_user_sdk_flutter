# Changelog

## 0.1.0

- Flutter Future/Stream API trên native Android/iOS: phiên, readiness, gọi/nhận, mute, audio route, DTMF và media recovery.
- Native bootstrap/push trước Dart, nhận cuộc gọi qua Telecom/CallKit và giao diện nghe/gọi SDK.
- Demo khách hàng, đăng nhập/đăng xuất, Gọi CSKH, trở lại cuộc gọi và hướng dẫn tích hợp riêng.
