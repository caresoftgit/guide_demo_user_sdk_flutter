package vn.caresoft.customervoice.flutter

import vn.caresoft.customervoice.*

internal object VoiceState {
 private var revision=0L
 fun session(s: SessionInfo)=mapOf("userId" to s.userId,"sessionId" to s.sessionId,"expiresAt" to s.expiresAt.toString())
 fun readiness(r: VoiceReadiness)=mapOf("sessionStatus" to r.sessionStatus.name,"isLoggedIn" to r.isLoggedIn,"canCall" to r.canCall,"canReceive" to r.canReceive,"userId" to r.userId,"reasons" to r.reasons,"checkedAt" to r.checkedAt?.toString(),"controlConnected" to r.controlConnected)
 fun route(r: AudioRoute)=mapOf("id" to r.id,"name" to r.name,"selected" to r.selected)
 fun call(c: CallSnapshot)=mapOf("callId" to c.callId,"direction" to c.direction,"state" to c.state,"version" to c.version.toString(),"businessNumber" to c.businessNumber,"ringingExpiresAt" to c.ringingExpiresAt?.toString(),"mediaExpiresAt" to c.mediaExpiresAt?.toString(),"endedAt" to c.endedAt?.toString(),"endReason" to c.endReason,"deviceStatus" to c.deviceStatus,"isOwner" to c.isOwner,"presentable" to CustomerVoice.isCallPresentable(c.callId))
 fun snapshot(): Map<String,Any?> {
  val s=when(val state=CustomerVoice.sessionState.value) {
   is SessionState.Authenticated -> mapOf("status" to "authenticated","session" to session(state.session))
   is SessionState.LoginRequired -> mapOf("status" to "loginRequired","reason" to state.reason)
   SessionState.LoggedOut -> mapOf("status" to "loggedOut")
  }
  return mapOf("revision" to (++revision).toDouble(),"sessionState" to s,"readiness" to readiness(CustomerVoice.readiness.value),"calls" to CustomerVoice.calls.value.map(::call),"audioStates" to CustomerVoice.audioStates.value.mapValues {(_,v)->mapOf("muted" to v.muted,"routes" to v.routes.map(::route))},"connectionStates" to CustomerVoice.connectionStates.value.mapValues {it.value.name})
 }
}
