package vn.caresoft.customervoice.flutter

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.PluginRegistry
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import vn.caresoft.customervoice.*
import vn.caresoft.customervoice.ui.CustomerVoiceUi

class CustomerVoicePlugin: FlutterPlugin,MethodChannel.MethodCallHandler,ActivityAware,PluginRegistry.RequestPermissionsResultListener {
 private lateinit var context: Context
 private var engine: FlutterPlugin.FlutterPluginBinding?=null
 private var methods: MethodChannel?=null
 private var activity: ActivityPluginBinding?=null
 private val permissions=PermissionRequests()
 private val streams=mutableListOf<NativeStream>()
 override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
  engine=binding;context=binding.applicationContext
  methods=MethodChannel(binding.binaryMessenger,"caresoft.customer_voice/methods").also {it.setMethodCallHandler(this)}
  for(state in listOf(true,false)) {
   val stream=NativeStream(state);streams.add(stream)
   EventChannel(binding.binaryMessenger,if(state)"caresoft.customer_voice/state" else "caresoft.customer_voice/events").setStreamHandler(stream)
  }
 }
 override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
  engine=null;methods?.setMethodCallHandler(null);methods=null
  streams.forEach {it.onCancel(null)};streams.clear();detachActivity()
 }
 private class NativeStream(val state: Boolean): EventChannel.StreamHandler {
  private var job: Job?=null
  override fun onListen(args: Any?,sink: EventChannel.EventSink) {
   job?.cancel()
   job=VoiceBootstrap.scope.launch {
    if(state)combine(CustomerVoice.sessionState,CustomerVoice.readiness,CustomerVoice.calls,CustomerVoice.audioStates,CustomerVoice.connectionStates){_,_,_,_,_->VoiceState.snapshot()}.collect {sink.success(it)}
    else CustomerVoice.events.collect {sink.success(mapOf("type" to it.type,"callId" to it.callId,"code" to it.code))}
   }
  }
  override fun onCancel(args: Any?) {job?.cancel();job=null}
 }
 override fun onMethodCall(call: MethodCall,result: MethodChannel.Result) {
  if(call.method!="execute") {result.notImplemented();return}
  val captured=engine
  // A Dart detach removes observers, never native in-flight operations or media.
  VoiceBootstrap.scope.launch {
   try {
    val envelope=call.arguments as? Map<*,*> ?: throw VoiceException("INVALID_ARGUMENT")
    val method=envelope["method"] as? String ?: throw VoiceException("INVALID_ARGUMENT")
    val args=envelope["args"] as? Map<*,*> ?: throw VoiceException("INVALID_ARGUMENT")
    fun string(key: String)=args[key] as? String ?: throw VoiceException("INVALID_ARGUMENT")
    if(method !in listOf("getState","initialize","canShowIncomingScreen"))VoiceBootstrap.requireInitialized()
    val value: Any?=when(method) {
     "initialize"->{VoiceBootstrap.checkConfiguration(string("backendUrl"),string("accountId"),string("appId"));null}
     "getState"->VoiceState.snapshot()
     "login"->VoiceState.session(CustomerVoice.login(string("userId"),string("tenantApiToken")))
     "logout"->{CustomerVoice.logout();null}
     "checkReadiness"->VoiceState.readiness(CustomerVoice.checkReadiness())
     "call"->VoiceState.call(CustomerVoice.call(string("businessNumber")))
     "answer"->{CustomerVoice.answer(string("callId"));null}
     "reject"->{CustomerVoice.reject(string("callId"));null}
     "hangup"->{CustomerVoice.hangup(string("callId"));null}
     "setMuted"->{CustomerVoice.setMuted(string("callId"),args["muted"] as? Boolean ?: throw VoiceException("INVALID_ARGUMENT"));null}
     "getAvailableAudioRoutes"->CustomerVoice.getAvailableAudioRoutes(string("callId")).map(VoiceState::route)
     "selectAudioRoute"->{val id=string("callId");val route=CustomerVoice.getAvailableAudioRoutes(id).firstOrNull {it.id==string("routeId")} ?: throw VoiceException("ROUTE_UNAVAILABLE");CustomerVoice.selectAudioRoute(id,route);null}
     "sendDtmf"->{val digit=string("digit");if(digit.length!=1)throw VoiceException("INVALID_DTMF");CustomerVoice.sendDtmf(string("callId"),digit[0]);null}
     "updatePushToken"->{VoiceBootstrap.updatePushToken(string("token"));null}
     "unregisterPushToken"->{VoiceBootstrap.unregisterPushToken();null}
     "synchronize"->{CustomerVoice.synchronize();VoiceState.snapshot()}
     "resume"->{VoiceBootstrap.resume();null}
     "showCall"->{CustomerVoiceUi.showCall(context,string("callId"));null}
     "canShowIncomingScreen"->CustomerVoiceUi.canShowIncomingScreen(context)
     "requestIncomingScreenPermission"->{CustomerVoiceUi.requestIncomingScreenPermission(activity?.activity ?: throw VoiceException("ACTIVITY_REQUIRED"));null}
     "requestMicrophonePermission"->permission(Manifest.permission.RECORD_AUDIO)
     "requestNotificationPermission"->if(Build.VERSION.SDK_INT>=33)permission(Manifest.permission.POST_NOTIFICATIONS) else true
     else->throw VoiceException("UNSUPPORTED_OPERATION")
    }
    if(engine===captured&&captured!=null)result.success(value)
   } catch(e: Exception) {
    val code=when(e){is VoiceException->e.code;is IllegalArgumentException->"INVALID_ARGUMENT";else->"VOICE_OPERATION_FAILED"}
    if(engine===captured&&captured!=null)result.error(code,code,mapOf("status" to ((e as? VoiceException)?.status ?: 0)))
   }
  }
 }
 private suspend fun permission(name: String): Boolean {
  if(ContextCompat.checkSelfPermission(context,name)==PackageManager.PERMISSION_GRANTED)return true
  val host=activity?.activity ?: throw VoiceException("ACTIVITY_REQUIRED")
  val request=try {permissions.begin(name)}catch(_: IllegalStateException){throw VoiceException("PERMISSION_REQUEST_IN_PROGRESS")}
  try {ActivityCompat.requestPermissions(host,arrayOf(name),request.code);return request.result.await()}
  finally {permissions.release(request)}
 }
 override fun onRequestPermissionsResult(code: Int,names: Array<out String>,grants: IntArray): Boolean {
  return permissions.complete(code,names,grants.firstOrNull()==PackageManager.PERMISSION_GRANTED)
 }
 private fun detachActivity() {activity?.removeRequestPermissionsResultListener(this);activity=null;permissions.detach()}
 override fun onAttachedToActivity(binding: ActivityPluginBinding) {activity=binding;binding.addRequestPermissionsResultListener(this)}
 override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding)=onAttachedToActivity(binding)
 override fun onDetachedFromActivityForConfigChanges()=detachActivity()
 override fun onDetachedFromActivity()=detachActivity()
}
