# Customer Voice SDK cho Flutter

Plugin `caresoft_customer_voice` 0.1.0 hỗ trợ Android và iOS. Dùng chung core/UI native Android 0.4.2 và iOS 0.1.2; không tạo media/session engine trong Dart.

Đã ghim Flutter 3.50.1 / Dart 3.14.0, Android API 26+ / compileSdk 37 / JDK 17, iOS 15.1+ / Xcode 26.4 và CocoaPods. Không hỗ trợ Flutter Web/desktop. Demo và hướng dẫn tích hợp nằm trong bộ bàn giao riêng.

Cài bản archive đã kèm native artifacts từ bộ demo. Source repo chỉ chứa bridge/API và script chuẩn bị; không cài trực tiếp source Git thiếu artifact native. Native Application/AppDelegate phải bootstrap trước Dart để nhận cuộc gọi nền.

```dart
final voice = CustomerVoice.instance;
final subscription = voice.states.listen((state) {
  // state.readiness.canCall / canReceive; state.calls[].presentable.
});
await voice.login(authenticatedCustomerId, accountApiToken);
if ((await voice.checkReadiness()).canCall) {
  await voice.call(assignedBusinessNumber);
}
// subscription.cancel() chỉ bỏ observer; không logout/hangup.
```

Token account chỉ truyền vào login sau xác thực của host. Không đặt token vào source, config, preferences hoặc log. UI cuộc gọi có sẵn ở native; `showCall(callId)` mở lại call còn presentable, không tạo cuộc gọi. Không retry call khi mất response; chờ `synchronize()` thành công.

## Phát triển

```sh
flutter pub get
flutter test
flutter analyze
python3 scripts/prepare-native.py --ios /path/to/clean-ios-distribution --android /path/to/maven
python3 scripts/package.py --output /path/to/caresoft_customer_voice-0.1.0.tar.gz
python3 scripts/verify-package.py /path/to/caresoft_customer_voice-0.1.0.tar.gz
```

Giữ license/resources/privacy và checksum native. Không đưa đường dẫn máy build hoặc credential vào artifact. Không tự publish pub.dev hoặc TestFlight. Xem [API](docs/api.md).
