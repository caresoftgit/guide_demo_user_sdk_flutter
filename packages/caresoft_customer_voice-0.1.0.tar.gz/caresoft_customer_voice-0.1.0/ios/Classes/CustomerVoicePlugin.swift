import Flutter
import Foundation
import Combine
import AVFoundation
import UserNotifications
import CustomerVoice

@MainActor public final class CustomerVoicePlugin: NSObject, @preconcurrency FlutterPlugin {
 private var attached=true
 private var streams=[VoiceStream]()
 public static func register(with registrar: FlutterPluginRegistrar) {
  let plugin=CustomerVoicePlugin()
  registrar.publish(plugin)
  let channel=FlutterMethodChannel(name:"caresoft.customer_voice/methods",binaryMessenger:registrar.messenger())
  registrar.addMethodCallDelegate(plugin,channel:channel)
  FlutterEventChannel(name:"caresoft.customer_voice/state",binaryMessenger:registrar.messenger()).setStreamHandler(plugin.stream(true))
  FlutterEventChannel(name:"caresoft.customer_voice/events",binaryMessenger:registrar.messenger()).setStreamHandler(plugin.stream(false))
 }
 private func stream(_ state: Bool)->VoiceStream {let value=VoiceStream(state:state);streams.append(value);return value}
 public func detachFromEngine(for registrar: FlutterPluginRegistrar) {attached=false;streams.forEach {_ = $0.onCancel(withArguments:nil)};streams.removeAll()}
 public func handle(_ call: FlutterMethodCall,result callback: @escaping FlutterResult) {
  let reply: FlutterResult = {[weak self] value in if self?.attached==true {callback(value)}}
  guard call.method=="execute" else {reply(FlutterMethodNotImplemented);return}
  // Native operations finish independently of a Dart observer/engine lifetime.
  Task {@MainActor in
   do {
    guard let envelope=call.arguments as? [String:Any],let method=envelope["method"] as? String,let args=envelope["args"] as? [String:Any] else {throw VoiceError("INVALID_ARGUMENT")}
    let v=CustomerVoice.shared
    func string(_ key: String)throws->String {guard let value=args[key] as? String else {throw VoiceError("INVALID_ARGUMENT")};return value}
    if !["getState","initialize","canShowIncomingScreen"].contains(method),v.configuration==nil {throw VoiceError("NATIVE_BOOTSTRAP_REQUIRED")}
    var result:Any?=nil
    switch method {
    case "initialize":
     guard let c=v.configuration else {throw VoiceError("NATIVE_BOOTSTRAP_REQUIRED")}
     guard c.backendURL.absoluteString==((try string("backendUrl"))),c.accountID==((try string("accountId"))),c.appID==((try string("appId"))),c.pushEnvironment.rawValue==(args["pushEnvironment"] as? String ?? "production") else {throw VoiceError("CONFIGURATION_MISMATCH")}
    case "getState": result=VoiceState.snapshot()
    case "login": result=VoiceState.session(try await v.login(userID:string("userId"),tenantAPIToken:string("tenantApiToken")))
    case "logout":try await v.logout()
    case "checkReadiness":result=VoiceState.readiness(try await v.checkReadiness())
    case "call":result=VoiceState.call(try await v.call(businessNumber:string("businessNumber")))
    case "answer":try await v.answer(callID:string("callId"))
    case "reject":try await v.reject(callID:string("callId"))
    case "hangup":try await v.hangup(callID:string("callId"))
    case "setMuted":guard let muted=args["muted"] as? Bool else {throw VoiceError("INVALID_ARGUMENT")};try await v.setMuted(callID:string("callId"),muted:muted)
    case "getAvailableAudioRoutes":result=v.getAvailableAudioRoutes(callID:try string("callId")).map(VoiceState.route)
    case "selectAudioRoute":let id=try string("callId");let routeID=try string("routeId");guard let route=v.getAvailableAudioRoutes(callID:id).first(where:{$0.id==routeID}) else {throw VoiceError("ROUTE_UNAVAILABLE")};try await v.selectAudioRoute(callID:id,route:route)
    case "sendDtmf":let digit=try string("digit");guard digit.count==1,let value=digit.first else {throw VoiceError("INVALID_DTMF")};try await v.sendDtmf(callID:string("callId"),digit:value)
    case "updatePushToken":try await v.updatePushToken(string("token"))
    case "unregisterPushToken":try await v.unregisterPushToken()
    case "synchronize":try await v.synchronize();result=VoiceState.snapshot()
    case "resume":VoiceBootstrap.resume()
    case "showCall":try VoiceBootstrap.showCall(string("callId"))
    case "canShowIncomingScreen":result=true
    case "requestIncomingScreenPermission":break // iOS CallKit has no Android full-screen special access.
    case "requestNotificationPermission":result=await withCheckedContinuation {c in UNUserNotificationCenter.current().requestAuthorization(options:[.alert,.sound,.badge]) {granted,_ in c.resume(returning:granted)}};v.resume()
    case "requestMicrophonePermission":result=await withCheckedContinuation {c in AVAudioSession.sharedInstance().requestRecordPermission {c.resume(returning:$0)}};v.resume()
    default:throw VoiceError("UNSUPPORTED_OPERATION")
    }
    reply(result)
   } catch {
    let error=error as? VoiceError ?? VoiceError("VOICE_OPERATION_FAILED")
    reply(FlutterError(code:error.code,message:error.code,details:["status":error.status]))
   }
  }
 }
}

@MainActor private final class VoiceStream: NSObject,@preconcurrency FlutterStreamHandler {
 let state: Bool
 var observations=Set<AnyCancellable>()
 init(state: Bool){self.state=state;super.init()}
 func onListen(withArguments arguments: Any?,eventSink events: @escaping FlutterEventSink)->FlutterError? {
  observations.removeAll();let v=CustomerVoice.shared
  if state {
   Publishers.MergeMany(v.$sessionState.map{_ in ()}.eraseToAnyPublisher(),v.$readiness.map{_ in ()}.eraseToAnyPublisher(),v.$calls.map{_ in ()}.eraseToAnyPublisher(),v.$audioStates.map{_ in ()}.eraseToAnyPublisher(),v.$connectionStates.map{_ in ()}.eraseToAnyPublisher()).receive(on:DispatchQueue.main).sink {_ in events(VoiceState.snapshot())}.store(in:&observations)
  } else {
   v.events.receive(on:DispatchQueue.main).sink {event in events(["type":event.type,"callId":event.callID ?? NSNull() as Any,"code":event.code ?? NSNull() as Any])}.store(in:&observations)
  }
  return nil
 }
 func onCancel(withArguments arguments: Any?)->FlutterError? {observations.removeAll();return nil}
}
