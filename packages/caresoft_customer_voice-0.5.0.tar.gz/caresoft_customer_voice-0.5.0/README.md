# Customer Voice Flutter SDK 0.5.0

Use [secure ticket login](docs/secure-sessions.md) with your authenticated enterprise backend. Shared REST/API credentials never go in the app.

# Customer Voice SDK cho Flutter

Plugin `caresoft_customer_voice` 0.5.0 hỗ trợ Android và iOS. Dùng chung core/UI native Android 0.5.0 và iOS 0.5.0; không tạo media/session engine trong Dart.

Đã ghim Flutter 3.50.1 / Dart 3.14.0, Android API 26+ / compileSdk 37 / JDK 17, iOS 15.1+ / Xcode 26.4 và CocoaPods. Không hỗ trợ Flutter Web/desktop. Demo và hướng dẫn tích hợp nằm trong bộ bàn giao riêng.

Cài bản archive đã kèm native artifacts từ [bộ demo](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/tree/main/packages), rồi làm theo [hướng dẫn tích hợp từng bước](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/blob/main/docs/integration.md). Source repo chỉ chứa bridge/API và script chuẩn bị; không cài trực tiếp source Git thiếu artifact native. Native Application/AppDelegate phải bootstrap trước Dart để nhận cuộc gọi nền.

```dart
final voice = CustomerVoice.instance;
final subscription = voice.states.listen((state) {
  // state.readiness.canCall / canReceive; state.calls[].presentable.
});
await voice.initialize(VoiceConfig(
  backendUrl: gatewayUrl,
  accountId: accountId,
  appId: caresoftAppId,
  pushEnvironment: 'production',
));
final preparation = await voice.prepareLogin();
// enterpriseBootstrap: API của backend doanh nghiệp, dùng phiên host đã xác thực.
final ticket = await enterpriseBootstrap(preparation.toMap());
await voice.loginWithTicket(preparation.attemptId, ticket.loginTicket);
if ((await voice.checkReadiness()).canCall) {
  await voice.call(assignedBusinessNumber);
}
// subscription.cancel() chỉ bỏ observer; không logout/hangup.
```

Credential tích hợp chỉ giữ ở backend doanh nghiệp. App nhận ticket một lần; không nhận API token account. Không đặt token vào source, config, preferences hoặc log. UI cuộc gọi có sẵn ở native; `showCall(callId)` mở lại call còn presentable, không tạo cuộc gọi. Không retry call khi mất response; chờ `synchronize()` thành công.

## Cấu trúc source

| Thư mục | Nội dung |
|---|---|
| `lib/` | Public Dart API, models, state/event streams |
| `android/` | Kotlin bridge, native bootstrap và chuyển tiếp push |
| `ios/` | Swift bridge, native bootstrap và kết nối giao diện SDK |
| `test/`, `android/src/test/` | Kiểm thử API và các trạng thái bridge |
| `scripts/` | Chuẩn bị native artifacts, đóng gói và xác minh checksum |
| `native-manifest.json` | Phiên bản và SHA-256 từng file native |

Source lõi native được quản lý tại [Android SDK](https://github.com/caresoftgit/user_voice_sdk_android) và [iOS SDK](https://github.com/caresoftgit/user_voice_sdk_ios). Repo này chứa phần thích ứng Flutter; cùng một gateway phục vụ hai nền tảng.

## Phát triển và đóng gói

Xem [hướng dẫn build SDK](docs/building.md) để chuẩn bị đúng native artifacts, chạy kiểm thử và tạo archive. Giữ license/resources/privacy và checksum native. Không đưa đường dẫn máy build hoặc credential vào artifact. Package phân phối qua archive trong repo demo, chưa phân phối qua pub.dev.

- [API Dart](docs/api.md)
- [Tích hợp, tạo App Caresoft và cấu hình push](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/blob/main/docs/integration.md)
- [Chạy demo Android/iOS](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/blob/main/docs/demo.md)
