import 'dart:async';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:caresoft_customer_voice/caresoft_customer_voice.dart';

Map<String, Object?> snapshot(int revision) => {
  'revision': revision,
  'sessionState': {'status': 'loggedOut'},
  'readiness': {
    'sessionStatus': 'LOGGED_OUT',
    'isLoggedIn': false,
    'canCall': false,
    'canReceive': false,
    'userId': null,
    'reasons': ['LOGIN_REQUIRED'],
    'checkedAt': null,
    'controlConnected': false,
  },
  'calls': [],
  'audioStates': {},
  'connectionStates': {},
  'accessToken': 'must-not-escape',
};

class Harness implements VoiceTransport {
  final stateController = StreamController<Object?>.broadcast(sync: true);
  final eventController = StreamController<Object?>.broadcast(sync: true);
  final operations = <String>[];
  Future<Object?> Function(String, Map<String, Object?>)? handler;
  @override
  Stream<Object?> get states => stateController.stream;
  @override
  Stream<Object?> get events => eventController.stream;
  @override
  Future<Object?> execute(String method, Map<String, Object?> args) async {
    operations.add(method);
    if (handler != null) return handler!(method, args);
    return method == 'getState' || method == 'synchronize' ? snapshot(1) : null;
  }

  Future<void> close() async {
    await stateController.close();
    await eventController.close();
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Harness h;
  late CustomerVoiceClient client;
  setUp(() {
    h = Harness();
    client = CustomerVoiceClient(h);
  });
  tearDown(() async {
    await client.dispose();
    await h.close();
  });
  test(
    'ambiguous create is sent once and errors hide transport secrets',
    () async {
      h.handler = (m, a) async {
        throw PlatformException(
          code: 'UNAVAILABLE',
          message: 'private value',
          details: {'status': 503, 'accessToken': 'secret'},
        );
      };
      try {
        await client.call('18001234');
        fail('must fail');
      } on CustomerVoiceException catch (e) {
        expect(e.code, 'UNAVAILABLE');
        expect(e.status, 503);
        expect(e.toString(), isNot(contains('private')));
        expect(e.toString(), isNot(contains('secret')));
      }
      expect(h.operations, ['call']);
    },
  );
  test('invalid destination never reaches native', () async {
    await expectLater(
      client.call('sip:example.com'),
      throwsA(
        isA<CustomerVoiceException>().having(
          (e) => e.code,
          'code',
          'INVALID_BUSINESS_NUMBER',
        ),
      ),
    );
    expect(h.operations, isEmpty);
  });
  test('new state wins over delayed initial snapshot', () async {
    final initial = Completer<Object?>();
    h.handler = (m, a) => initial.future;
    final revisions = <int>[];
    final sub = client.states.listen((s) => revisions.add(s.revision));
    h.stateController.add(snapshot(4));
    initial.complete(snapshot(1));
    await Future<void>.delayed(Duration.zero);
    expect(revisions, [4]);
    await sub.cancel();
  });
  test('cancel and dispose detach only; late snapshot cannot reach removed observer', () async {
    final initial = Completer<Object?>();
    h.handler = (m, a) => initial.future;
    final states = <VoiceState>[];
    final sub = client.states.listen(states.add);
    await sub.cancel();
    initial.complete(snapshot(2));
    await Future<void>.delayed(Duration.zero);
    await client.dispose();
    expect(states, isEmpty);
    expect(h.operations, ['getState']);
  });
  test(
    'reattach fetches current native snapshot without login or call',
    () async {
      final first = client.states.listen((_) {});
      await Future<void>.delayed(Duration.zero);
      await first.cancel();
      h.handler = (m, a) async => snapshot(9);
      expect((await client.states.first).revision, 9);
      expect(h.operations, ['getState', 'getState']);
    },
  );
  test('synchronize waits for reconciliation response', () async {
    final done = Completer<Object?>();
    h.handler = (m, a) => done.future;
    var returned = false;
    final pending = client.synchronize().then((s) {
      returned = true;
      return s;
    });
    await Future<void>.delayed(Duration.zero);
    expect(returned, false);
    done.complete(snapshot(7));
    expect((await pending).revision, 7);
    expect(h.operations, ['synchronize']);
  });
  test(
    'typed snapshot keeps public fields and no raw credential storage',
    () async {
      h.handler = (m, a) async => snapshot(1);
      final s = await client.getState();
      expect(s.sessionState.status, 'loggedOut');
      expect(s.readiness.reasons, ['LOGIN_REQUIRED']);
      expect(s.readiness.canCall, false);
      expect(() => s.readiness.reasons.add('other'), throwsUnsupportedError);
    },
  );
  test(
    'missing native link gives actionable code and no raw message',
    () async {
      h.handler = (m, a) async => throw MissingPluginException('path/private');
      await expectLater(
        client.resume(),
        throwsA(
          isA<CustomerVoiceException>().having(
            (e) => e.code,
            'code',
            'NATIVE_MODULE_NOT_LINKED',
          ),
        ),
      );
    },
  );
  test(
    'events are live only and safe errors reject malformed native responses',
    () async {
      final events = <VoiceEvent>[];
      final sub = client.events.listen(events.add);
      h.eventController.add({
        'type': 'error',
        'callId': 'call-example',
        'code': 'NETWORK_RECOVERY_TIMEOUT',
      });
      expect(events.single.code, 'NETWORK_RECOVERY_TIMEOUT');
      await sub.cancel();
      h.handler = (m, a) async => {'revision': 'bad', 'accessToken': 'private'};
      await expectLater(
        client.getState(),
        throwsA(
          isA<CustomerVoiceException>().having(
            (e) => e.code,
            'code',
            'INVALID_NATIVE_RESPONSE',
          ),
        ),
      );
    },
  );
  test('notification permission reports the native result', () async {
    h.handler = (method, args) async => false;
    expect(await client.requestNotificationPermission(), false);
  });
}
