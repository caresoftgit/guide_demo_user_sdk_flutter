import 'dart:async';

import 'package:flutter_test/flutter_test.dart';
import 'package:caresoft_customer_voice/caresoft_customer_voice.dart';

import 'client_test.dart' show Harness;

const attempt = '00000000-0000-4000-8000-000000000001';
final preparation = <String, Object?>{
  'attemptId': attempt,
  'installationId': '00000000-0000-4000-8000-000000000002',
  'platform': 'ios',
  'applicationId': 'com.example.app',
  'pushEnvironment': 'production',
  'codeChallenge': List.filled(43, 'c').join(),
  'codeChallengeMethod': 'S256',
  'codeVerifier': 'must-not-escape',
};
final session = <String, Object?>{
  'userId': '42',
  'sessionId': attempt,
  'expiresAt': '2026-11-22T03:15:00Z',
  'sessionExpiresAt': '2026-11-22T04:00:00Z',
  'accessToken': 'must-not-escape',
};
void main() {
  late Harness h;
  late CustomerVoiceClient client;
  setUp(() {
    h = Harness();
    client = CustomerVoiceClient(h);
  });
  tearDown(() async {
    await client.dispose();
    await h.close();
  });
  test(
    'preparation returns only public PKCE metadata for host bootstrap',
    () async {
      h.handler = (m, a) async => preparation;
      final p = await client.prepareLogin();
      expect(p.toMap().keys.toSet(), {
        'attemptId',
        'installationId',
        'platform',
        'applicationId',
        'pushEnvironment',
        'codeChallenge',
        'codeChallengeMethod',
      });
      expect(p.attemptId, attempt);
      expect(p.toMap().values, isNot(contains('must-not-escape')));
    },
  );
  test(
    'ticket login forwards only attempt and ticket and decodes absolute expiry',
    () async {
      Map<String, Object?>? payload;
      h.handler = (m, a) async {
        payload = a;
        return session;
      };
      final s = await client.loginWithTicket(
        attempt,
        List.filled(43, 't').join(),
      );
      expect(payload, {
        'attemptId': attempt,
        'ticket': List.filled(43, 't').join(),
      });
      expect(s.sessionExpiresAt, DateTime.utc(2026, 11, 22, 4));
      expect(h.operations, ['loginWithTicket']);
    },
  );
  test('malformed attempt and ticket never reach native', () async {
    await expectLater(
      client.loginWithTicket('not-a-uuid', 'bad'),
      throwsA(isA<CustomerVoiceException>()),
    );
    expect(h.operations, isEmpty);
  });
  test(
    'malformed native preparation fails without leaking raw fields',
    () async {
      h.handler = (m, a) async => {
        ...preparation,
        'codeChallengeMethod': 'plain',
      };
      await expectLater(
        client.prepareLogin(),
        throwsA(
          isA<CustomerVoiceException>().having(
            (e) => e.code,
            'code',
            'INVALID_NATIVE_RESPONSE',
          ),
        ),
      );
    },
  );
  test('late login result after logout cannot be returned as an authenticated session', () async {
    final gate = Completer<Object?>();
    h.handler = (m, a) async => m == 'loginWithTicket' ? gate.future : null;
    final login = client.loginWithTicket(attempt, List.filled(43, 't').join());
    await client.logout();
    gate.complete(session);
    await expectLater(
      login,
      throwsA(
        isA<CustomerVoiceException>().having(
          (e) => e.code,
          'code',
          'SESSION_CHANGED',
        ),
      ),
    );
  });
}
