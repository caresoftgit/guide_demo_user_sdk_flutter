#!/usr/bin/env python3
"""Copy pinned shared native distributions. Do not vendor another media engine."""
from pathlib import Path
import argparse,shutil,json,hashlib
p=argparse.ArgumentParser();p.add_argument('--ios',type=Path,required=True);p.add_argument('--android',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
for source,target in [(a.ios,root/'ios/Vendor'),(a.android,root/'android/maven')]:
 assert source.resolve()!=target.resolve(),'Input and output must differ'
 if target.exists():shutil.rmtree(target)
 shutil.copytree(source,target)
manifest={'flutter':'3.50.1','dart':'3.14.0','ios':'0.5.0','androidCore':'0.5.0','androidUI':'0.5.0','sha256':{}}
for name in ['ios/Vendor','android/maven']:
 for f in sorted((root/name).rglob('*')):
  if f.is_file() and f.name!='.DS_Store':manifest['sha256'][str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
(root/'native-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared',len(manifest['sha256']),'native files')
