#!/usr/bin/env python3
"""Copy pinned shared native distributions. Do not vendor another media engine."""
from pathlib import Path
import argparse,shutil,json,hashlib,re,subprocess
p=argparse.ArgumentParser();p.add_argument('--ios',type=Path,required=True);p.add_argument('--android',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1]
for source,target in [(a.ios,root/'ios/Vendor'),(a.android,root/'android/maven')]:
 assert source.resolve()!=target.resolve(),'Input and output must differ'
 if target.exists():shutil.rmtree(target)
 shutil.copytree(source,target)
# Strip debug metadata; runtime source locations require build-time prefix maps.
for framework in (root/'ios/Vendor').rglob('*.framework'):
 binary=framework/framework.stem
 if framework.stem in ['CustomerVoice','CustomerVoiceUI'] and binary.is_file():subprocess.run(['xcrun','strip','-S',str(binary)],check=True)
for pattern in ['*.abi.json','*.swiftsourceinfo']:
 for file in (root/'ios/Vendor').rglob(pattern):file.unlink()
for file in (root/'ios/Vendor').rglob('*'):
 if file.is_file() and file.name!='.DS_Store':
  assert not re.search(rb'/(?:Users|source/users)/[^/\s\x00]+/',file.read_bytes().replace(b'\\/',b'/'),re.IGNORECASE),'Rebuild native framework with source prefix maps: '+str(file.relative_to(root))
manifest={'flutter':'3.50.1','dart':'3.14.0','ios':'0.5.0','androidCore':'0.5.0','androidUI':'0.5.0','sha256':{}}
for name in ['ios/Vendor','android/maven']:
 for f in sorted((root/name).rglob('*')):
  if f.is_file() and f.name!='.DS_Store':manifest['sha256'][str(f.relative_to(root))]=hashlib.sha256(f.read_bytes()).hexdigest()
(root/'native-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Prepared',len(manifest['sha256']),'native files')
