#!/usr/bin/env python3
"""Check the archive the consumer actually installs, including nested AAR/JAR."""
from pathlib import PurePosixPath
import argparse,hashlib,io,json,plistlib,re,tarfile,zipfile
p=argparse.ArgumentParser();p.add_argument('archive');a=p.parse_args()
def privacy(name,data):
 path_data=data.replace(b'\\/',b'/')
 assert not re.search(rb'/(?:Users|source/users)/[^/\s\x00]+/',path_data,re.IGNORECASE),'Developer path: '+name
 assert not re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----\r?\n[A-Za-z0-9+/=]{32,}',data),'Private key: '+name
 if data.startswith(b'PK'):
  with zipfile.ZipFile(io.BytesIO(data)) as z:
   for n in z.namelist():
    if not n.endswith('/'):privacy(name+'!'+n,z.read(n))
with tarfile.open(a.archive) as t:
 assert all(m.uid==0 and m.gid==0 and not m.uname and not m.gname for m in t.getmembers()),'Builder identity in archive metadata'
 files={m.name.removeprefix('caresoft_customer_voice-0.5.0/'):m for m in t.getmembers() if m.isfile()}
 def read(name):return t.extractfile(files[name]).read()
 manifest=json.loads(read('native-manifest.json'));assert manifest['ios']=='0.5.0' and manifest['androidCore']==manifest['androidUI']=='0.5.0'
 for name,digest in manifest['sha256'].items():assert hashlib.sha256(read(name)).hexdigest()==digest,'Checksum: '+name
 for name in ['pubspec.yaml','lib/caresoft_customer_voice.dart','ios/caresoft_customer_voice.podspec','android/build.gradle','THIRD_PARTY_NOTICES.md']:read(name)
 for name in files:
  assert '..' not in PurePosixPath(name).parts and not name.startswith('/'),'Unsafe path'
  assert not any(part in ['.git','build','Pods','.dart_tool','.gradle'] for part in PurePosixPath(name).parts),'Build/private directory: '+name
  assert not any(x in name for x in ['.local.','.p8','.p12','.mobileprovision','GoogleService-Info.plist','google-services.json']), 'Private config: '+name
  assert not name.endswith(('.abi.json','.swiftsourceinfo')),'Development source metadata: '+name
  data=read(name);privacy(name,data)
  if name.endswith('.framework/Info.plist'):
   info=plistlib.loads(data)
   for key in ['CFBundleShortVersionString','CFBundleVersion']:assert info.get(key),'Framework version missing: '+name
 assert any('PrivacyInfo.xcprivacy' in n for n in files)
 assert any('ios-arm64_x86_64-simulator' in n for n in files)
 print('PASS: Flutter 0.5.0,',len(manifest['sha256']),'native checksums; privacy/resources/licenses and nested archive checks')
