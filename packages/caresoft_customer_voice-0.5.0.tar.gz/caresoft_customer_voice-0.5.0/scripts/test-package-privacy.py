#!/usr/bin/env python3
"""Exercise the installed archive verifier against nested and escaped metadata."""
import io
from pathlib import Path
import runpy
import sys
import unittest
import zipfile

archive = sys.argv.pop(1)
verifier = Path(__file__).with_name('verify-package.py')
saved_args = sys.argv
sys.argv = [str(verifier), archive]
privacy = runpy.run_path(str(verifier))['privacy']
sys.argv = saved_args


class PackagePrivacyTest(unittest.TestCase):
    def test_source_remapped_paths_are_rejected(self):
        data = ('/' + '/'.join(['source', 'users', 'example', 'SDK.swift'])).encode()
        with self.assertRaises(AssertionError):
            privacy('metadata', data)

    def test_json_escaped_paths_are_rejected(self):
        data = ('/' + '/'.join(['Users', 'example', 'SDK.swift'])).replace('/', r'\/').encode()
        with self.assertRaises(AssertionError):
            privacy('metadata.json', data)

    def test_nested_archives_are_scanned(self):
        data = io.BytesIO()
        with zipfile.ZipFile(data, 'w') as nested:
            nested.writestr('metadata.json', ('/' + '/'.join(['source', 'users', 'example', 'SDK.swift'])).encode())
        with self.assertRaises(AssertionError):
            privacy('native.aar', data.getvalue())


unittest.main()
