#!/usr/bin/env python3
"""Build a self-contained Flutter path-dependency archive from an allowlist."""
from pathlib import Path
import argparse,tarfile
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parents[1];a.output.parent.mkdir(parents=True,exist_ok=True)
def public_metadata(info):
 info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;info.pax_headers={}
 return info
allowed=['pubspec.yaml','pubspec.lock','lib','android','ios','native-manifest.json','README.md','CHANGELOG.md','THIRD_PARTY_NOTICES.md','docs','scripts','test']
with tarfile.open(a.output,'w:gz') as archive:
 for name in allowed:
  path=root/name
  assert path.exists(),'Missing public package input: '+name
  files=[path] if path.is_file() else sorted(path.rglob('*'))
  for f in files:
   if not f.is_file() or any(part in ['build','.gradle','Pods','.dart_tool','__pycache__'] for part in f.relative_to(root).parts) or f.name=='.DS_Store':continue
   assert not f.is_symlink(),'Symlink in public package: '+str(f.relative_to(root))
   archive.add(f,'caresoft_customer_voice-0.5.0/'+str(f.relative_to(root)),recursive=False,filter=public_metadata)
print(a.output)
