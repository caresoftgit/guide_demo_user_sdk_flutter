# Changelog

## 0.5.0

- Host-issued PKCE ticket login; native-owned tokens, refresh/logout lifecycle, native Android/iOS 0.5.0 distributions.
- Loại debug/source metadata khỏi native distribution và kiểm tra đường dẫn trong archive lồng nhau/JSON escaped.
- Hướng dẫn callback ticket qua HTTP client đã xác thực, ánh xạ principal server-side và logout/outbox doanh nghiệp.

## 0.1.0

- Flutter Future/Stream API trên native Android/iOS: phiên, readiness, gọi/nhận, mute, audio route, DTMF và media recovery.
- Native bootstrap/push trước Dart, nhận cuộc gọi qua Telecom/CallKit và giao diện nghe/gọi SDK.
- Demo khách hàng, đăng nhập/đăng xuất, Gọi CSKH, trở lại cuộc gọi và hướng dẫn tích hợp riêng.
- Bổ sung hướng dẫn build/đóng gói source, liên kết bộ demo và xác minh gói native bằng checksum.
