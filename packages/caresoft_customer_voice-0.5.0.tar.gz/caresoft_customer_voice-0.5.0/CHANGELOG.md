## 0.5.0

Host-issued PKCE ticket login, native-owned tokens and refresh/logout lifecycle, native Android/iOS 0.5.0 distributions.

# Changelog

## 0.1.0

- Flutter Future/Stream API trên native Android/iOS: phiên, readiness, gọi/nhận, mute, audio route, DTMF và media recovery.
- Native bootstrap/push trước Dart, nhận cuộc gọi qua Telecom/CallKit và giao diện nghe/gọi SDK.
- Demo khách hàng, đăng nhập/đăng xuất, Gọi CSKH, trở lại cuộc gọi và hướng dẫn tích hợp riêng.
- Bổ sung hướng dẫn build/đóng gói source, liên kết bộ demo và xác minh gói native bằng checksum.
