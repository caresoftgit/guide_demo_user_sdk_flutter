# Phiên Voice protocol 2 trên Flutter

Ứng dụng giữ cơ chế đăng nhập/SSO hiện có. Backend xác thực phiên doanh nghiệp, ánh xạ principal sang `user_id` Caresoft và xin ticket một lần bằng credential tích hợp chỉ lưu ở server. App không cho người dùng nhập `user_id` hoặc API token Caresoft. SDK không cung cấp backend hay màn hình đăng nhập doanh nghiệp.

1. Native bootstrap từ Application/AppDelegate trước Dart, kể cả cold start do push.
2. `prepareLogin()` tạo verifier trong memory native và trả bảy trường preparation công khai.
3. HTTP client đã xác thực của ứng dụng gửi preparation tới backend doanh nghiệp; backend thêm định danh khách hàng, Account/App và phiên host từ dữ liệu đáng tin cậy.
4. Backend trả `{attempt_id, login_ticket, expires_at}`; ứng dụng kiểm tra đúng attempt và ticket chưa hết hạn trước khi gọi `loginWithTicket(attemptId, ticket)`.
5. Native exchange PKCE, giữ access/refresh và quản lý rotation, push, readiness, cuộc gọi và UI native. Dart chỉ nhận metadata phiên/state.

```dart
final preparation = await voice.prepareLogin();
// Callback của ứng dụng, dùng HTTP client với phiên doanh nghiệp hiện có.
// Callback kiểm tra attempt_id, expires_at và trả chuỗi login_ticket.
final ticket = await requestTicket(preparation);
final session = await voice.loginWithTicket(preparation.attemptId, ticket);
```

Callback ánh xạ preparation sang payload backend:

| Dart | Payload bootstrap |
|---|---|
| `attemptId` | `attempt_id` |
| `installationId` | `installation_id` |
| `platform` | `os` |
| `applicationId` | `application_id` |
| `pushEnvironment` | `push_environment` |
| `codeChallenge` | `code_challenge` |
| `codeChallengeMethod` | `code_challenge_method` (`S256`) |

`LoginPreparation.toMap()` dùng tên camelCase của Dart, không tự chuyển thành payload snake_case. Không thêm `user_id`, API token hoặc verifier từ phía client. Backend lấy định danh khách hàng từ principal đã xác thực; preparation không thay xác thực doanh nghiệp hoặc chứng thực thiết bị.

Preparation sống tối đa 120 giây; ticket một lần mặc định 60 giây; access thường 15 phút. Hạn tuyệt đối do chính sách server và phiên host quyết định; refresh không kéo dài hạn đó. Native refresh single-flight lưu UUID trước HTTP và retry cùng payload/UUID trong cửa sổ 30 giây sau response thất lạc/restart. Exchange lỗi hoặc mất response cần preparation/ticket mới. `prepareLogin()` không ngắt media hiện tại.

Native dùng Keychain trên iOS và storage được bảo vệ bằng Android Keystore. Không lưu token vào Dart persistence, preferences, assets hoặc config. Verifier/ticket không persist; access/refresh không đi qua MethodChannel. Protocol 1 không dùng cho tích hợp mới. Redact ticket, push token, enterprise bearer, credentials và payload push khỏi log, URL, analytics và crash report.

`logout()` dọn local trước và cố thu hồi phiên Voice; lỗi revoke không khôi phục token đã xóa. Ngắt Voice không đăng xuất tài khoản doanh nghiệp. Đăng xuất ứng dụng phải thực hiện cả SDK logout và logout backend, kể cả một bên lỗi, trong coordinator tuần tự hóa với kết nối/chuyển tài khoản. Backend vô hiệu hóa phiên host và ghi durable HOST-revoke outbox cùng transaction; worker retry/poll đến cleanup hoàn tất. Logout offline chưa bảo đảm thu hồi server ngay; giao diện cần báo chưa xác nhận thu hồi.

Hết hạn tự nhiên chặn cuộc gọi mới; cuộc gọi ACTIVE đang có có thể tiếp tục bằng capability giới hạn tới deadline server. Explicit revoke/logout dừng quyền phiên/media. Lỗi mạng có thể cho readiness UNKNOWN; không tự bootstrap lặp khi offline. `canReceive` không thay kiểm thử push thực tế.

Dùng package 0.5.0 với native Android core/UI và iOS 0.5.0. Application ID và push environment phải khớp provisioning. HTTPS/TLS bảo vệ API, WSS và WebRTC DTLS-SRTP bảo vệ giao tiếp/media. Vẫn cần nghiệm thu thiết bị thật cho cuộc gọi, push, nền/khóa màn hình và chuyển mạng.

Xem [API](api.md) và [hướng dẫn tích hợp](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/blob/main/docs/integration.md) để nối callback vào HTTP client của ứng dụng.
