# Secure ticket login 0.5.0

Your enterprise backend authenticates the customer and owns their Caresoft user_id mapping. REST and integration credentials stay on servers. Flutter receives only public preparation metadata and a one-use ticket; verifier, access, refresh and call capabilities remain inside native Android/iOS cores.

```dart
final p = await voice.prepareLogin();
final ticket = await enterprise.bootstrap({
  'attempt_id': p.attemptId, 'installation_id': p.installationId,
  'os': p.platform, 'application_id': p.applicationId,
  'push_environment': p.pushEnvironment,
  'code_challenge': p.codeChallenge, 'code_challenge_method': p.codeChallengeMethod,
});
if (ticket['attempt_id'] != p.attemptId) throw StateError('STALE_BOOTSTRAP');
final session = await voice.loginWithTicket(p.attemptId, ticket['login_ticket']);
```

Authenticate bootstrap with your enterprise session, not an SDK or API shared secret. Never accept user_id from editable client input. A failed/unknown ticket exchange requires a new preparation/ticket; never fallback to legacy login. Preparation times out locally after 120 seconds; gateway ticket TTL is 60 seconds, one use and PKCE S256 bound. Calling prepareLogin does not interrupt current media.

Native core automatically rotates access/refresh, including same-UUID refresh recovery within 30 seconds after a lost response/restart. Access normally lasts 15 minutes; sessionExpiresAt is an absolute deadline bounded by host expiry/app policy. No token is sent through MethodChannel or stored in Dart.

Call, incoming/native UI, microphone/notification and audio APIs are unchanged. At natural expiry new calls stop while an owned ACTIVE call can finish using bounded call-only authority. Explicit revoke/logout ends media. Logout SDK and enterprise session; enterprise backend must invalidate its session and enqueue durable HOST revoke even during gateway outages. Client offline logout alone cannot guarantee immediate server cleanup.

Use SDK package 0.5.0 with bundled native core/UI 0.5.0. Initialize native bootstrap before Dart for PushKit/FCM cold start. Native application ID and push environment must match gateway provisioning. Demo enterprise bearer is memory only; production applications provide their own durable host login/logout workflow. Physical-device push/background/network acceptance is still required.

`login(userId, tenantApiToken)` is deprecated demo-only compatibility and is not the recommended integration. Never bundle integration/REST credentials in Dart/native config, assets, logs or screenshots.
