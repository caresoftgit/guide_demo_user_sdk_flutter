# Build và đóng gói SDK Flutter

## 1. Chuẩn bị

Dùng Flutter 3.50.1 / Dart 3.14.0. Build Android cần JDK 17 và toolchain Android; build iOS cần macOS, Xcode 26.4 và CocoaPods. Repo này không chứa thư mục output native `ios/Vendor` và `android/maven`.

Để phát triển bridge mà giữ nguyên core native, lấy đúng artifact 0.5.0 từ repo demo:

```sh
git clone https://github.com/caresoftgit/user_voice_sdk_flutter.git
git clone https://github.com/caresoftgit/guide_demo_user_sdk_flutter.git
cd guide_demo_user_sdk_flutter
python3 scripts/install_sdk.py
cd ../user_voice_sdk_flutter
python3 scripts/prepare-native.py \
  --ios ../guide_demo_user_sdk_flutter/vendor/caresoft_customer_voice-0.5.0/ios/Vendor \
  --android ../guide_demo_user_sdk_flutter/vendor/caresoft_customer_voice-0.5.0/android/maven
```

`install_sdk.py` kiểm tra checksum archive và từng file native trước khi giải nén. Bản 0.5.0 ghim Android core/UI 0.5.0 và iOS 0.5.0. Không trộn các phiên bản native khác vào cùng gói.

Nếu thay đổi core native, build distribution từ repo Android/iOS tương ứng rồi truyền hai thư mục distribution vào `prepare-native.py`. Giữ privacy manifest, resources và third-party licenses. Dùng đường dẫn build trung lập và prefix-map tới /source/sdk hoặc /source/artifacts khi build native để không đóng đường dẫn máy cá nhân vào binary. Không dùng prefix-map còn giữ tên người dùng dưới thư mục /source. Script prepare-native.py strip debug symbols và bỏ ABI/source-location metadata; nếu đường dẫn vẫn ở diagnostic string trong binary thì cần build lại native bằng prefix-map đúng. Không dùng artifact chứa cấu hình ứng dụng hoặc thông tin ký.

## 2. Kiểm tra và tạo archive

Chạy từ thư mục source SDK đã chuẩn bị native:

```sh
flutter --no-version-check pub get
flutter --no-version-check test
flutter --no-version-check analyze
python3 scripts/package.py --output build/caresoft_customer_voice-0.5.0.tar.gz
python3 scripts/verify-package.py build/caresoft_customer_voice-0.5.0.tar.gz
python3 scripts/test-package-privacy.py build/caresoft_customer_voice-0.5.0.tar.gz
```

Archive gồm bridge Dart/Kotlin/Swift và native artifacts cho Android, iOS device và iOS Simulator. Verifier kiểm tra phiên bản, SHA-256 native, metadata framework, resources/privacy/licenses, đường dẫn riêng và archive AAR/JAR lồng nhau. Không bỏ qua lỗi checksum.

## 3. Cập nhật bộ demo

Chỉ sau khi kiểm tra đạt:

```sh
cp build/caresoft_customer_voice-0.5.0.tar.gz ../guide_demo_user_sdk_flutter/packages/
cd ../guide_demo_user_sdk_flutter
shasum -a 256 packages/caresoft_customer_voice-0.5.0.tar.gz > packages/SHA256SUMS
python3 scripts/install_sdk.py
python3 scripts/configure.py
flutter --no-version-check pub get
flutter --no-version-check test
flutter --no-version-check analyze
```

Kiểm tra build Android/iOS theo [hướng dẫn demo](https://github.com/caresoftgit/guide_demo_user_sdk_flutter/blob/main/docs/demo.md), rồi nghiệm thu trên thiết bị thật trước khi phân phối. Khi thay version package, cập nhật đồng bộ pubspec, podspec, scripts, dependency path, archive và tài liệu. Không commit native output, cấu hình local, token, private key, profile ký hoặc file build.
