import Foundation
import UIKit
import CustomerVoice
import CustomerVoiceUI

/// Native app lifetime; initialize in AppDelegate before a Dart runtime exists.
@MainActor public enum VoiceBootstrap {
 private static var presenter: CustomerVoicePresenter?
 private static weak var presenterHost: UIViewController?
 public static func initialize(backendURL: URL,accountID: String,appID: String,supportName: String="Chăm sóc khách hàng",environment: PushEnvironment = .production,managesPushKit: Bool=true) throws {
  try CustomerVoice.shared.initialize(config:VoiceConfig(backendURL:backendURL,accountID:accountID,appID:appID,pushEnvironment:environment,supportName:supportName,managesPushKit:managesPushKit))
  UIApplication.shared.registerForRemoteNotifications()
 }
 public static func attach(to host: UIViewController) {
  guard presenterHost !== host || presenter==nil else {return}
  presenterHost=host;presenter=CustomerVoiceUI.install(on:host)
 }
 public static func resume() {CustomerVoice.shared.resume();if let c=CustomerVoice.shared.calls.first(where:{CustomerVoice.shared.isCallPresentable($0.callID)}) {presenter?.showCall(callID:c.callID)}}
 public static func showCall(_ id: String) throws {
  guard CustomerVoice.shared.isCallPresentable(id) else {throw VoiceError("CALL_NOT_PRESENTABLE")}
  if presenter==nil,let host=UIApplication.shared.connectedScenes.compactMap({$0 as? UIWindowScene}).flatMap({$0.windows}).first(where:{$0.isKeyWindow})?.rootViewController {attach(to:host)}
  guard let presenter else {throw VoiceError("HOST_VIEW_REQUIRED")};presenter.showCall(callID:id)
 }
 public static func didRegisterForRemoteNotifications(deviceToken: Data) {CustomerVoice.shared.didRegisterForRemoteNotifications(deviceToken:deviceToken)}
 public static func handleRemoteNotification(_ payload: [AnyHashable:Any]) async -> Bool {await CustomerVoice.shared.handleRemoteNotification(payload)}
}
