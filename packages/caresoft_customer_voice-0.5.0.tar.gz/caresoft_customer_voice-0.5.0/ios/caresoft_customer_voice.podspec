Pod::Spec.new do |s|
  s.name = 'caresoft_customer_voice'
  s.version = '0.5.0'
  s.summary = 'Caresoft customer voice SDK with native call UI for Flutter'
  s.homepage = 'https://caresoft.vn'
  s.license = { :type => 'Proprietary' }
  s.author = { 'Caresoft' => 'https://caresoft.vn' }
  s.source = { :path => '.' }
  s.source_files = 'Classes/**/*'
  s.dependency 'Flutter'
  s.platform = :ios, '15.1'
  s.swift_version = '5.0'
  s.vendored_frameworks = 'Vendor/*.xcframework'
  s.resources = 'Vendor/Resources/*.bundle'
  s.preserve_paths = 'Vendor/Licenses/**/*'
  s.frameworks = 'CallKit', 'PushKit', 'AVFoundation', 'UserNotifications', 'SwiftUI'
  s.pod_target_xcconfig = { 'DEFINES_MODULE' => 'YES' }
end
