import 'package:flutter/services.dart';

abstract interface class VoiceTransport {
  Future<Object?> execute(String method, Map<String, Object?> args);
  Stream<Object?> get states;
  Stream<Object?> get events;
}

class PlatformVoiceTransport implements VoiceTransport {
  static const _methods = MethodChannel('caresoft.customer_voice/methods');
  late final Stream<Object?> _states = const EventChannel(
    'caresoft.customer_voice/state',
  ).receiveBroadcastStream();
  late final Stream<Object?> _events = const EventChannel(
    'caresoft.customer_voice/events',
  ).receiveBroadcastStream();
  @override
  Future<Object?> execute(String method, Map<String, Object?> args) => _methods
      .invokeMethod<Object?>('execute', {'method': method, 'args': args});
  @override
  Stream<Object?> get states => _states;
  @override
  Stream<Object?> get events => _events;
}
