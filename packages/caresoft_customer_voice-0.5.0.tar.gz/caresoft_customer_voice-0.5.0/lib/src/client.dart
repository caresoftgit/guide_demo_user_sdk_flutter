import 'dart:async';

import 'package:flutter/services.dart';

import 'models.dart';
import 'transport.dart';

class CustomerVoiceClient {
  CustomerVoiceClient(this._transport);
  final VoiceTransport _transport;
  int _sessionEpoch = 0;
  final _detach = <Future<void> Function()>{};
  CustomerVoiceException _safe(Object error) {
    if (error is CustomerVoiceException) return error;
    if (error is MissingPluginException)
      return CustomerVoiceException('NATIVE_MODULE_NOT_LINKED');
    if (error is PlatformException) {
      final details = error.details;
      final status = details is Map ? details['status'] : null;
      return CustomerVoiceException(
        error.code,
        status: status is int ? status : 0,
      );
    }
    return CustomerVoiceException('VOICE_OPERATION_FAILED');
  }

  Future<Object?> _invoke(
    String method, [
    Map<String, Object?> args = const {},
  ]) async {
    try {
      return await _transport.execute(method, args);
    } catch (error) {
      throw _safe(error);
    }
  }

  T _decode<T>(Object? value, T Function(Map<String, Object?>) factory) {
    try {
      return factory(voiceMap(value));
    } catch (_) {
      throw CustomerVoiceException('INVALID_NATIVE_RESPONSE');
    }
  }

  Future<T> _model<T>(
    String method,
    T Function(Map<String, Object?>) factory, [
    Map<String, Object?> args = const {},
  ]) async => _decode(await _invoke(method, args), factory);
  Future<void> _control(
    String method, [
    Map<String, Object?> args = const {},
  ]) async {
    await _invoke(method, args);
  }

  Future<void> initialize(VoiceConfig config) =>
      _control('initialize', config.toMap());
  Future<LoginPreparation> prepareLogin() async {
    final epoch = _sessionEpoch;
    final value = await _model('prepareLogin', LoginPreparation.fromMap);
    if (epoch != _sessionEpoch) throw CustomerVoiceException('SESSION_CHANGED');
    return value;
  }

  Future<SessionInfo> loginWithTicket(String attemptId, String ticket) async {
    if (!RegExp(
          r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
        ).hasMatch(attemptId) ||
        !RegExp(r'^[A-Za-z0-9_-]{43}$').hasMatch(ticket)) {
      throw CustomerVoiceException('INVALID_ARGUMENT');
    }
    final epoch = _sessionEpoch;
    final result = await _model('loginWithTicket', SessionInfo.fromMap, {
      'attemptId': attemptId,
      'ticket': ticket,
    });
    if (epoch != _sessionEpoch) throw CustomerVoiceException('SESSION_CHANGED');
    return result;
  }

  @Deprecated('Legacy protocol 1. Use prepareLogin/loginWithTicket.')
  Future<SessionInfo> login(String userId, String tenantApiToken) => _model(
    'login',
    SessionInfo.fromMap,
    {'userId': userId, 'tenantApiToken': tenantApiToken},
  );
  Future<void> logout() {
    _sessionEpoch++;
    return _control('logout');
  }

  Future<VoiceReadiness> checkReadiness() =>
      _model('checkReadiness', VoiceReadiness.fromMap);
  Future<CallSnapshot> call(String businessNumber) async {
    if (!RegExp(r'^\+?[0-9]{1,32}$').hasMatch(businessNumber))
      throw CustomerVoiceException('INVALID_BUSINESS_NUMBER');
    return _model('call', CallSnapshot.fromMap, {
      'businessNumber': businessNumber,
    });
  }

  Future<void> answer(String callId) => _control('answer', {'callId': callId});
  Future<void> reject(String callId) => _control('reject', {'callId': callId});
  Future<void> hangup(String callId) => _control('hangup', {'callId': callId});
  Future<void> setMuted(String callId, bool muted) =>
      _control('setMuted', {'callId': callId, 'muted': muted});
  Future<List<AudioRoute>> getAvailableAudioRoutes(String callId) async {
    final value = await _invoke('getAvailableAudioRoutes', {'callId': callId});
    try {
      return List.unmodifiable(
        (value as List).map((v) => AudioRoute.fromMap(voiceMap(v))),
      );
    } catch (_) {
      throw CustomerVoiceException('INVALID_NATIVE_RESPONSE');
    }
  }

  Future<void> selectAudioRoute(String callId, String routeId) =>
      _control('selectAudioRoute', {'callId': callId, 'routeId': routeId});
  Future<void> sendDtmf(String callId, String digit) =>
      _control('sendDtmf', {'callId': callId, 'digit': digit});
  Future<void> showCall(String callId) =>
      _control('showCall', {'callId': callId});
  Future<VoiceState> getState() => _model('getState', VoiceState.fromMap);
  Future<VoiceState> synchronize() => _model('synchronize', VoiceState.fromMap);
  Future<void> resume() => _control('resume');
  Future<void> updatePushToken(String token) =>
      _control('updatePushToken', {'token': token});
  Future<void> unregisterPushToken() => _control('unregisterPushToken');
  Future<bool> requestMicrophonePermission() async =>
      await _invoke('requestMicrophonePermission') == true;
  Future<bool> requestNotificationPermission() async =>
      await _invoke('requestNotificationPermission') == true;
  Future<bool> canShowIncomingScreen() async =>
      await _invoke('canShowIncomingScreen') == true;
  Future<void> requestIncomingScreenPermission() =>
      _control('requestIncomingScreenPermission');
  Stream<T> _observe<T>(
    Stream<Object?> source,
    T Function(Map<String, Object?>) factory, {
    bool initial = false,
  }) => Stream<T>.multi((controller) {
    var active = true;
    var revision = -1;
    void deliver(Object? raw) {
      if (!active) return;
      try {
        final value = _decode(raw, factory);
        if (value is VoiceState) {
          if (value.revision <= revision) return;
          revision = value.revision;
        }
        controller.addSync(value);
      } catch (error) {
        controller.addErrorSync(_safe(error));
      }
    }

    final subscription = source.listen(
      deliver,
      onError: (Object e, StackTrace st) {
        if (active) controller.addErrorSync(_safe(e));
      },
    );
    late Future<void> Function() stop;
    stop = () async {
      if (!active) return;
      active = false;
      _detach.remove(stop);
      await subscription.cancel();
      controller.closeSync();
    };
    _detach.add(stop);
    controller.onCancel = stop;
    if (initial)
      unawaited(
        _invoke('getState').then(deliver).catchError((Object e) {
          if (active) controller.addErrorSync(_safe(e));
        }),
      );
  }, isBroadcast: true);
  Stream<VoiceState> get states =>
      _observe(_transport.states, VoiceState.fromMap, initial: true);
  Stream<VoiceEvent> get events =>
      _observe(_transport.events, VoiceEvent.fromMap);

  /// Detaches Dart observers only. Native session, media and UI remain alive.
  Future<void> dispose() async {
    for (final off in _detach.toList()) {
      await off();
    }
  }
}

class CustomerVoice {
  CustomerVoice._();
  static final instance = CustomerVoiceClient(PlatformVoiceTransport());
}
