Map<String, Object?> voiceMap(Object? value) =>
    Map<String, Object?>.from(value as Map);
String _string(Map<String, Object?> m, String key) => m[key] as String;
bool _bool(Map<String, Object?> m, String key) => m[key] as bool;
List<T> _list<T>(Object? value, T Function(Object?) decode) =>
    List.unmodifiable((value as List).map(decode));

class CustomerVoiceException implements Exception {
  CustomerVoiceException(String code, {this.status = 0})
    : code = RegExp(r'^[A-Z][A-Z0-9_]{0,127}$').hasMatch(code)
          ? code
          : 'VOICE_OPERATION_FAILED';
  final String code;
  final int status;
  @override
  String toString() => 'CustomerVoiceException($code, status: $status)';
}

class VoiceConfig {
  const VoiceConfig({
    required this.backendUrl,
    required this.accountId,
    required this.appId,
    this.supportName = 'Chăm sóc khách hàng',
    this.pushEnvironment = 'production',
  });
  final String backendUrl, accountId, appId, supportName, pushEnvironment;
  Map<String, Object?> toMap() => {
    'backendUrl': backendUrl,
    'accountId': accountId,
    'appId': appId,
    'supportName': supportName,
    'pushEnvironment': pushEnvironment,
  };
}

class LoginPreparation {
  LoginPreparation.fromMap(Map<String, Object?> m)
    : attemptId = _string(m, 'attemptId'),
      installationId = _string(m, 'installationId'),
      platform = _string(m, 'platform'),
      applicationId = _string(m, 'applicationId'),
      pushEnvironment = _string(m, 'pushEnvironment'),
      codeChallenge = _string(m, 'codeChallenge'),
      codeChallengeMethod = _string(m, 'codeChallengeMethod') {
    final uuid = RegExp(
      r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
    );
    if (!uuid.hasMatch(attemptId) ||
        !uuid.hasMatch(installationId) ||
        !['ios', 'android'].contains(platform) ||
        applicationId.isEmpty ||
        codeChallengeMethod != 'S256' ||
        !RegExp(r'^[A-Za-z0-9_-]{43}$').hasMatch(codeChallenge) ||
        (platform == 'ios'
            ? !['sandbox', 'production'].contains(pushEnvironment)
            : pushEnvironment != 'default'))
      throw const FormatException();
  }
  final String attemptId,
      installationId,
      platform,
      applicationId,
      pushEnvironment,
      codeChallenge,
      codeChallengeMethod;
  Map<String, Object?> toMap() => {
    'attemptId': attemptId,
    'installationId': installationId,
    'platform': platform,
    'applicationId': applicationId,
    'pushEnvironment': pushEnvironment,
    'codeChallenge': codeChallenge,
    'codeChallengeMethod': codeChallengeMethod,
  };
}

class SessionInfo {
  SessionInfo.fromMap(Map<String, Object?> m)
    : userId = _string(m, 'userId'),
      sessionId = _string(m, 'sessionId'),
      expiresAt = DateTime.parse(_string(m, 'expiresAt')),
      sessionExpiresAt = m['sessionExpiresAt'] == null
          ? null
          : DateTime.parse(_string(m, 'sessionExpiresAt'));
  final String userId, sessionId;
  final DateTime expiresAt;
  final DateTime? sessionExpiresAt;
}

class SessionState {
  SessionState.fromMap(Map<String, Object?> m)
    : status = _string(m, 'status'),
      session = m['session'] == null
          ? null
          : SessionInfo.fromMap(voiceMap(m['session'])),
      reason = m['reason'] as String? {
    if (!['loggedOut', 'authenticated', 'loginRequired'].contains(status) ||
        (status == 'authenticated' && session == null))
      throw const FormatException();
  }
  final String status;
  final SessionInfo? session;
  final String? reason;
}

class VoiceReadiness {
  VoiceReadiness.fromMap(Map<String, Object?> m)
    : sessionStatus = _string(m, 'sessionStatus'),
      isLoggedIn = _bool(m, 'isLoggedIn'),
      canCall = _bool(m, 'canCall'),
      canReceive = _bool(m, 'canReceive'),
      userId = m['userId'] as String?,
      reasons = _list(m['reasons'], (v) => v as String),
      checkedAt = m['checkedAt'] == null
          ? null
          : DateTime.parse(m['checkedAt'] as String),
      controlConnected = _bool(m, 'controlConnected');
  final String sessionStatus;
  final bool isLoggedIn, canCall, canReceive, controlConnected;
  final String? userId;
  final List<String> reasons;
  final DateTime? checkedAt;
}

class CallSnapshot {
  CallSnapshot.fromMap(Map<String, Object?> m)
    : callId = _string(m, 'callId'),
      direction = _string(m, 'direction'),
      state = _string(m, 'state'),
      version = _string(m, 'version'),
      businessNumber = m['businessNumber'] as String?,
      ringingExpiresAt = _date(m['ringingExpiresAt']),
      mediaExpiresAt = _date(m['mediaExpiresAt']),
      endedAt = _date(m['endedAt']),
      endReason = m['endReason'] as String?,
      deviceStatus = m['deviceStatus'] as String?,
      isOwner = _bool(m, 'isOwner'),
      presentable = _bool(m, 'presentable');
  static DateTime? _date(Object? v) =>
      v == null ? null : DateTime.parse(v as String);
  final String callId, direction, state, version;
  final String? businessNumber, endReason, deviceStatus;
  final DateTime? ringingExpiresAt, mediaExpiresAt, endedAt;
  final bool isOwner, presentable;
}

class AudioRoute {
  AudioRoute.fromMap(Map<String, Object?> m)
    : id = _string(m, 'id'),
      name = _string(m, 'name'),
      selected = _bool(m, 'selected');
  final String id, name;
  final bool selected;
}

class CallAudioState {
  CallAudioState.fromMap(Map<String, Object?> m)
    : muted = _bool(m, 'muted'),
      routes = _list(m['routes'], (v) => AudioRoute.fromMap(voiceMap(v)));
  final bool muted;
  final List<AudioRoute> routes;
}

class VoiceState {
  VoiceState.fromMap(Map<String, Object?> m)
    : revision = (m['revision'] as num).toInt(),
      sessionState = SessionState.fromMap(voiceMap(m['sessionState'])),
      readiness = VoiceReadiness.fromMap(voiceMap(m['readiness'])),
      calls = _list(m['calls'], (v) => CallSnapshot.fromMap(voiceMap(v))),
      audioStates = Map.unmodifiable(
        voiceMap(m['audioStates'])
            .map((k, v) => MapEntry(k, CallAudioState.fromMap(voiceMap(v)))),
      ),
      connectionStates = Map.unmodifiable(
        voiceMap(m['connectionStates']).map((k, v) => MapEntry(k, v as String)),
      ) {
    if (revision < 0 || revision != m['revision'])
      throw const FormatException();
  }
  final int revision;
  final SessionState sessionState;
  final VoiceReadiness readiness;
  final List<CallSnapshot> calls;
  final Map<String, CallAudioState> audioStates;
  final Map<String, String> connectionStates;
}

class VoiceEvent {
  VoiceEvent.fromMap(Map<String, Object?> m)
    : type = _string(m, 'type'),
      callId = m['callId'] as String?,
      code = m['code'] as String?;
  final String type;
  final String? callId, code;
}
