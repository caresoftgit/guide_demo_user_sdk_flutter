package vn.caresoft.customervoice.flutter

import org.junit.Assert.*
import org.junit.Test
import kotlinx.coroutines.ExperimentalCoroutinesApi

@OptIn(ExperimentalCoroutinesApi::class)
class PermissionRequestsTest {
 @Test fun staleResultCannotCompleteNewActivityRequest() {
  val requests=PermissionRequests()
  val old=requests.begin("microphone")
  requests.detach()
  assertEquals(false,old.result.getCompleted())
  val current=requests.begin("notifications")
  assertNotEquals(old.code,current.code)
  assertFalse(requests.complete(old.code,arrayOf("microphone"),true))
  assertFalse(current.result.isCompleted)
  assertFalse(requests.complete(current.code,arrayOf("microphone"),true))
  assertTrue(requests.complete(current.code,arrayOf("notifications"),false))
  assertEquals(false,current.result.getCompleted())
 }
 @Test fun interruptedMatchingRequestCompletesDeniedAndReleasesSlot() {
  val requests=PermissionRequests();val request=requests.begin("microphone")
  assertTrue(requests.complete(request.code,emptyArray(),false))
  assertEquals(false,request.result.getCompleted())
  val replacement=requests.begin("notifications")
  assertFalse(requests.complete(request.code,arrayOf("microphone"),true))
  assertFalse(replacement.result.isCompleted)
 }
 @Test fun concurrentRequestsRejectedAndCompletionReleasesSlot() {
  val requests=PermissionRequests();val first=requests.begin("microphone")
  try {requests.begin("notifications");fail("must reject concurrent request")}catch(_:IllegalStateException) {}
  assertTrue(requests.complete(first.code,arrayOf("microphone"),true))
  assertEquals(true,first.result.getCompleted())
  requests.begin("notifications")
 }
}
