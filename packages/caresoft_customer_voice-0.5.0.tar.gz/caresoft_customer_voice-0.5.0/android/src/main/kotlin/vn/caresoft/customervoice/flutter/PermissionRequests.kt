package vn.caresoft.customervoice.flutter

import kotlinx.coroutines.CompletableDeferred

/** Main-thread permission ownership; late results cannot complete a replacement request. */
internal class PermissionRequests {
 data class Request(val code: Int,val name: String,val result: CompletableDeferred<Boolean>)
 private var pending: Request?=null
 companion object { private var nextCode=7632 }
 fun begin(name: String): Request {
  check(pending==null) {"PERMISSION_REQUEST_IN_PROGRESS"}
  nextCode=if(nextCode==65535)1024 else nextCode+1
  return Request(nextCode,name,CompletableDeferred()).also {pending=it}
 }
 fun complete(code: Int,names: Array<out String>,granted: Boolean): Boolean {
  val request=pending ?: return false
  if(request.code!=code)return false
  if(names.isNotEmpty()&&(names.size!=1||names[0]!=request.name))return false
  pending=null;request.result.complete(names.isNotEmpty()&&granted);return true
 }
 fun detach() {val request=pending;pending=null;request?.result?.complete(false)}
 fun release(request: Request) {if(pending===request)detach()}
}
